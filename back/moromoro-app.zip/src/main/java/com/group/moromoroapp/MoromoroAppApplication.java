package com.group.moromoroapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@CrossOrigin(origins = "http://192.168.0.7:8080/")
public class MoromoroAppApplication {

  public static void main(String[] args) {
    SpringApplication.run(MoromoroAppApplication.class, args);
  }

}
